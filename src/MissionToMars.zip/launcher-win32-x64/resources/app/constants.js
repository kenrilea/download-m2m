const launcherRoot = __dirname;
const gameRoot = __dirname + "/game";
const updateServiceUri = "http://localhost:4000";

module.exports = {
  launcherRoot,
  gameRoot,
  updateServiceUri,
};
