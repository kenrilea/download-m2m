import styled from "styled-components";

export const Button = styled.button`
  padding: 1rem;
  border: 2px solid #993300;
  font-size: 24px;
  font-variant: small-caps;
  background-color: black;
  color: #993300;
  margin: 1rem;
  padding-right: 2rem;
  padding-left: 2rem;
`;
