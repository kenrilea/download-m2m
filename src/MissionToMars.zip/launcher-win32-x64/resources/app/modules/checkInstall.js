const fs = require("fs");
const { launcherRoot } = require("../constants.js");

const checkInstall = async () => {
  return new Promise((resolve, reject) => {
    fs.readFile(launcherRoot + "/manifest.json", (err, data) => {
      console.log("e", err);
      console.log("d", data);
      if (err) {
        if (err.code === "ENOENT") {
          resolve({ installed: false });
          return false;
        }
        reject(err);
      }
      resolve({ installed: true });
    });
  });
};

module.exports = checkInstall;
