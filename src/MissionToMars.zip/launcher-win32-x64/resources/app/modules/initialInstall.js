const getManifest = require("./getManifest");
const axios = require("axios");
const { updateServiceUri, launcherRoot } = require("../constants");
const fs = require("fs");

const initialInstall = async (targetRoot) => {
  console.log("installing mission to mars");
  // first we need the file manifest
  console.log("fetching file manifest");
  let manifest = await getManifest();
  // we then prepare the directory structure for the files
  if (!fs.existsSync(targetRoot)) {
    fs.mkdirSync(targetRoot);
  }
  // we get all of the game files
  const files = await Promise.all(
    manifest.map(async (fileData) => {
      return new Promise((resolve, reject) => {
        //console.log(fileData.path);
        let finalPath = fileData.path.replace(":root", targetRoot);
        let targetDir = finalPath.split("/");
        targetDir.pop();
        targetDir = targetDir.join("/");
        const exists = fs.existsSync(targetDir);
        if (!exists) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        try {
          const writeStream = fs.createWriteStream(
            fileData.path.replace(":root", targetRoot),
            { autoClose: true, emitClose: true }
          );
          writeStream.on("open", async (fd) => {
            const res = await axios.request({
              method: "post",
              headers: { "Content-Type": "application/json" },
              url: updateServiceUri + "/fetch-file",
              data: JSON.stringify({ file: fileData.path }),
              responseType: "arraybuffer",
            });
            writeStream.write(res.data);
          });
          writeStream.on("error", (e) => {
            //console.log("file write error", e);
          });
          writeStream.on("end", () => {
            console.log(writeStream);

            //fs.close(writeStream.fd, () => {});
          });
          resolve(true);
        } catch (e) {
          console.log(e);
          reject(e);
        }
      });
    })
  );
  //console.log(files);
  if (files.every((success) => success)) {
    fs.writeFile(launcherRoot + "/manifest.json", manifest, (e) => {
      if (e) console.log("manifest write error", e);
    });
    return { success: true };
  }
  return { success: false };
  //then we verify their contents
  //finally we put the files where they belong
};

module.exports = initialInstall;
